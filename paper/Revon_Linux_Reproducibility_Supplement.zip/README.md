# Online Resource 1

Revon Linux validation and manuscript evidence, 8 October 2026.

Current Linux evidence:
- evidence/linux-validation-20261008: 516 executions, 67 Linux tests.
- evidence/linux-final-supplement-20261008: 72 executions, 69 Linux tests.

Historical Windows threshold/calibration/pilot bundles are retained separately.
Do not pool timings across machines, protocols or source snapshots.
The fixed threshold can choose a slower path than forced log. Million-row Linux
runs are n=1 feasibility diagnostics and cannot support a reliable ranking.

Each Linux bundle includes its exact executed source, frozen protocol, raw
results, summaries and internal audits. See its README and local-verification.
The supplementary source was frozen before its measurement. Its core database
files match the main Linux snapshot; only measurement/verification code changed.
Internal audits establish consistency, not independent timing reproduction.

Manuscript regeneration: the tools/ scripts and their original model/Fig1 inputs
are included at their repository-relative paths. From the extracted root, create
paper/, install python-docx, matplotlib, numpy and pypdf, then run
python tools/finalize_linux_manuscripts.py. PDF export uses Microsoft Word through
tools/export_linux_papers.ps1 on Windows. Fonts and exporter versions can affect
pagination; regenerated files require a fresh visual review. Support scripts
are reference copies; the source-directory audits described in the bundle
READMEs do not require the original download tar archives.

Use support/setup_linux_validation.sh in a user-controlled Linux x86_64
environment, with curl, tar and Python venv available. Read the script first.
It pins CPython 3.14.3, Dolt 2.3.1, psutil 7.1.0 and PyArrow 25.0.1.
Use the matching archived source as your working directory, create tests/test_data,
set PYTHONHASHSEED=20261008, and run its tests before measurement. Use a new output
directory. Exact reproduction and audit commands are in the bundle READMEs.

Public source acquisition (raw records and generated databases are not included):
https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2024-01.parquet
Raw SHA-256:
c4d59da7bbc8abaeeeb1727947ee93d9891a71acb42854bd80db1571b2030510
Prepare with the matching source's experiments.public_dataset. For an archived
audit, match the supplied dataset.json metadata as well as the prepared record
hash. The public values are canonical JSON strings; correction histories are
generated. See the acquisition/usage details in the recorded dataset metadata.

No credentials, private keys, VM IPs, cloud account tokens, private reviewer
documents, raw TLC records or generated repository directories are included.
PACKAGE_SHA256SUMS.json covers all packaged source/evidence/support files.
